package mu.mc3.presales;

import java.util.*;
import java.math.BigDecimal;
import java.math.RoundingMode;

public final class PresalesEngine {

    private PresalesEngine() {}

    public static Map<String,Object> windowsServer(
            String edition,
            int servers,
            int processorsPerServer,
            int coresPerProcessor,
            int vmCount) {

        edition = edition == null ? "standard" : edition.trim().toLowerCase(Locale.ROOT);
        if (servers < 1 || processorsPerServer < 1 || coresPerProcessor < 1 || vmCount < 0)
            throw new IllegalArgumentException("Valeurs invalides.");

        int physicalCores = processorsPerServer * coresPerProcessor;
        int licensingBase = Math.max(16, Math.max(physicalCores, processorsPerServer * 8));

        LinkedHashMap<String,Object> out = new LinkedHashMap<>();
        out.put("Physical cores / server", physicalCores);
        out.put("Licensing base cores / server", licensingBase);

        if ("datacenter".equals(edition)) {
            out.put("Edition", "Datacenter");
            out.put("Total core licenses", licensingBase * servers);
            out.put("VM rights", "Unlimited on fully licensed host");
        } else {
            int stacks = Math.max(1, (int)Math.ceil(vmCount / 2.0));
            int total = licensingBase * stacks * servers;
            out.put("Edition", "Standard");
            out.put("Stacks / server", stacks);
            out.put("VM rights / server", stacks * 2);
            out.put("Total core licenses", total);
        }

        out.put("Validation", "Verify current Microsoft Product Terms before customer use.");
        return out;
    }

    public static Map<String,Object> sqlServer(
            String edition,
            String deployment,
            String model,
            int physicalOrVcores,
            int userCals) {

        edition = norm(edition, "standard");
        deployment = norm(deployment, "vm");
        model = norm(model, "per_core");

        LinkedHashMap<String,Object> out = new LinkedHashMap<>();
        out.put("Edition", title(edition));
        out.put("Deployment", deployment.toUpperCase(Locale.ROOT));

        if ("server_cal".equals(model)) {
            if (!"standard".equals(edition))
                throw new IllegalArgumentException("Server + CAL est limité à Standard dans ce moteur.");
            out.put("Licensing model", "Server + CAL");
            out.put("Server licenses", 1);
            out.put("User CALs", Math.max(0, userCals));
        } else {
            int minimum = "vm".equals(deployment) ? 4 : 4;
            int licensed = Math.max(minimum, physicalOrVcores);
            out.put("Licensing model", "Per Core");
            out.put("Licensed cores", licensed);
            out.put("2-core packs", (int)Math.ceil(licensed / 2.0));
            out.put("CALs required", "No SQL CALs under Per Core");
        }

        out.put("Validation", "Verify version-specific SQL Server Product Terms and SA/subscription rights.");
        return out;
    }

    public static Map<String,Object> m365Bom(List<String> products, List<Integer> quantities) {
        LinkedHashMap<String,Object> out = new LinkedHashMap<>();
        List<String> findings = new ArrayList<>();

        Set<String> seen = new HashSet<>();
        boolean bp = false, entra = false, intune = false, e3 = false, e5 = false;

        for (int i = 0; i < products.size(); i++) {
            String p = products.get(i) == null ? "" : products.get(i).trim();
            String k = p.toLowerCase(Locale.ROOT);
            if (!seen.add(k)) findings.add("Duplicate row: " + p);

            if (k.contains("business") && k.contains("premium")) bp = true;
            if (k.contains("entra") && k.contains("p1")) entra = true;
            if (k.contains("intune") && (k.contains("plan 1") || k.contains("p1"))) intune = true;
            if (k.contains("microsoft 365") && k.contains("e3")) e3 = true;
            if (k.contains("microsoft 365") && k.contains("e5")) e5 = true;
        }

        if ((bp || e3 || e5) && entra)
            findings.add("Potential overlap: suite + Entra ID P1. Verify current suite entitlement and user assignments.");
        if ((bp || e3 || e5) && intune)
            findings.add("Potential overlap: suite + Intune Plan 1. Verify current suite entitlement and user assignments.");

        out.put("Rows reviewed", products.size());
        out.put("Finding count", findings.size());
        out.put("Findings", findings);
        out.put("Validation", "This is a preliminary overlap checker, not a live SKU entitlement engine.");
        return out;
    }

    public static Map<String,Object> copilotStudio(
            int makers,
            int endUsers,
            Integer monthlyCredits,
            boolean predictableBudget) {

        LinkedHashMap<String,Object> out = new LinkedHashMap<>();
        out.put("Makers", Math.max(0, makers));
        out.put("End users", Math.max(0, endUsers));
        out.put("Capacity pack size", "25,000 Copilot Credits/month");

        if (monthlyCredits == null) {
            out.put("Recommended starting model", "PAYG pilot / measure consumption first");
            out.put("Capacity packs", "Not determinable without expected credits");
        } else {
            int packs = (int)Math.ceil(Math.max(0, monthlyCredits) / 25000.0);
            out.put("Expected credits / month", monthlyCredits);
            out.put("Estimated capacity packs", packs);
            out.put("Commercial model", predictableBudget ? "Prepaid capacity" : "PAYG");
        }

        out.put("Validation", "Credit consumption depends on agent capabilities. Verify current Microsoft Copilot Studio licensing.");
        return out;
    }

    public static Map<String,Object> keepit(int protectedUsers, String workloads, int sharedMailboxes) {
        LinkedHashMap<String,Object> out = new LinkedHashMap<>();
        out.put("Protected users", Math.max(0, protectedUsers));
        out.put("Shared mailboxes input", Math.max(0, sharedMailboxes));
        out.put("Workloads", workloads);
        out.put("Positioning", "Independent backup / recovery / resilience layer alongside Microsoft 365.");
        out.put("Discovery", Arrays.asList(
                "Which workloads must be independently recoverable?",
                "Required retention period?",
                "Recovery objectives / restore responsibility?",
                "Ransomware or admin-compromise scenario?",
                "Compliance/export requirements?"
        ));
        out.put("Validation", "Verify current Keepit seat classification and protected-resource counting.");
        return out;
    }

    public static Map<String,Object> bittitan(
            int users,
            String workloads,
            double representativeMailboxGb,
            boolean documents,
            boolean personalArchives,
            boolean outlookReconfig) {

        LinkedHashMap<String,Object> out = new LinkedHashMap<>();
        List<String> umbDrivers = new ArrayList<>();
        if (documents) umbDrivers.add("documents");
        if (personalArchives) umbDrivers.add("personal archives");
        if (outlookReconfig) umbDrivers.add("Outlook profile reconfiguration");

        out.put("Users", Math.max(1, users));
        out.put("Workloads", workloads);

        if (!umbDrivers.isEmpty()) {
            out.put("Recommended path", "User Migration Bundle");
            out.put("UMB licenses", Math.max(1, users));
            out.put("Reason", "Project includes: " + join(umbDrivers));
        } else {
            int perUser = Math.max(1, (int)Math.ceil(Math.max(0.0, representativeMailboxGb) / 50.0));
            out.put("Recommended path", representativeMailboxGb <= 50.0
                    ? "Compare Mailbox Migration License vs UMB"
                    : "Compare multiple Mailbox licenses vs UMB");
            out.put("Estimated mailbox licenses", perUser * Math.max(1, users));
            out.put("Mailbox allowance used", "50 GB per license/user");
        }

        out.put("Validation", "Verify current MigrationWiz endpoint guide and license names before purchase.");
        return out;
    }

    public static List<Map<String,String>> searchCspCsv(
            String csvContent,
            String query,
            String market,
            String segment) {

        List<Map<String,String>> rows = parseCsv(csvContent);
        List<Map<String,String>> out = new ArrayList<>();

        String q = safe(query).toLowerCase(Locale.ROOT);
        String mk = safe(market).toUpperCase(Locale.ROOT);
        String seg = safe(segment).toLowerCase(Locale.ROOT);

        for (Map<String,String> r : rows) {
            String product = pick(r, "ProductTitle", "Product Title");
            String sku = pick(r, "SkuTitle", "SKU Title");
            String m = pick(r, "Market").toUpperCase(Locale.ROOT);
            String s = pick(r, "Segment").toLowerCase(Locale.ROOT);
            String hay = (product + " " + sku + " " + pick(r,"ProductId") + " " + pick(r,"SkuId")).toLowerCase(Locale.ROOT);

            if (!q.isEmpty() && !hay.contains(q)) continue;
            if (!mk.isEmpty() && !m.equals(mk)) continue;
            if (!seg.isEmpty() && !s.contains(seg)) continue;

            LinkedHashMap<String,String> x = new LinkedHashMap<>();
            x.put("Product", product);
            x.put("SKU", sku);
            x.put("Market", m);
            x.put("Currency", pick(r,"Currency"));
            x.put("Segment", pick(r,"Segment"));
            x.put("Term", pick(r,"TermDuration","Term Duration"));
            x.put("Billing", pick(r,"BillingPlan","Billing Plan"));
            x.put("UnitPrice", pick(r,"UnitPrice","Unit Price"));
            x.put("ERP", pick(r,"ERP Price","ERPPrice"));
            x.put("EffectiveStart", pick(r,"EffectiveStartDate","Effective Start Date"));
            x.put("EndOfSale", pick(r,"EndOfSaleStartDate","End Of Sale Start Date"));
            out.add(x);
        }
        return out;
    }

    public static Map<String,Object> compareCspCsv(String oldCsv, String newCsv, String query) {
        List<Map<String,String>> oldRows = searchCspCsv(oldCsv, query, "", "");
        List<Map<String,String>> newRows = searchCspCsv(newCsv, query, "", "");

        Map<String,Map<String,String>> a = indexRows(oldRows);
        Map<String,Map<String,String>> b = indexRows(newRows);

        int added = 0, removed = 0, changed = 0;
        List<String> changes = new ArrayList<>();

        for (String k : a.keySet()) {
            if (!b.containsKey(k)) {
                removed++;
                changes.add("REMOVED: " + label(a.get(k)));
            } else if (!safe(a.get(k).get("UnitPrice")).equals(safe(b.get(k).get("UnitPrice")))) {
                changed++;
                changes.add("PRICE: " + label(b.get(k)) + " | "
                        + safe(a.get(k).get("UnitPrice")) + " -> " + safe(b.get(k).get("UnitPrice")));
            }
        }
        for (String k : b.keySet()) {
            if (!a.containsKey(k)) {
                added++;
                changes.add("ADDED: " + label(b.get(k)));
            }
        }

        LinkedHashMap<String,Object> out = new LinkedHashMap<>();
        out.put("Added", added);
        out.put("Removed", removed);
        out.put("Changed", changed);
        out.put("Changes", changes);
        out.put("Validation", "A removed row is not automatically proof of retirement. Verify replacement SKU and End-of-Sale.");
        return out;
    }

    public static Map<String,Object> partnerCenterRequest(
            String market,
            String view,
            String timeline,
            String month) {

        market = safe(market).toUpperCase(Locale.ROOT);
        view = norm(view, "software");
        timeline = norm(timeline, "current");

        if (market.length() != 2)
            throw new IllegalArgumentException("Market must be a two-letter code, e.g. FR.");
        if ("history".equals(timeline) && safe(month).length() != 6)
            throw new IllegalArgumentException("History requires YYYYMM.");

        String url = "https://api.partner.microsoft.com/v1.0/sales/pricesheets(Market='"
                + market + "',PricesheetView='" + view + "')/$value";
        if ("history".equals(timeline)) {
            url += "?timeline=history&month=" + safe(month);
        } else if ("future".equals(timeline)) {
            url += "?timeline=future";
        }

        LinkedHashMap<String,Object> out = new LinkedHashMap<>();
        out.put("Method", "GET");
        out.put("URL", url);
        out.put("Auth", "Authorized Partner Center application + user context required");
        out.put("Response", "CSV/file stream");
        return out;
    }

    public static String technicalBrief(
            String scenario,
            String environment,
            String requirements,
            String components,
            String risks) {

        return "# Presales Technical Brief\n\n"
                + "## Customer scenario\n" + safe(scenario) + "\n\n"
                + "## Current environment\n" + bullets(environment) + "\n\n"
                + "## Requirements\n" + bullets(requirements) + "\n\n"
                + "## Proposed technical components\n" + bullets(components) + "\n\n"
                + "## Risks and assumptions\n" + bullets(risks) + "\n\n"
                + "## Validation before handoff\n"
                + "- Validate current licensing and prerequisites.\n"
                + "- Confirm tenant/environment ownership.\n"
                + "- Confirm migration/deployment sequence.\n"
                + "- Record assumptions that can change the solution.\n";
    }

    public static String pretty(Map<String,?> map) {
        StringBuilder b = new StringBuilder();
        for (Map.Entry<String,?> e : map.entrySet()) {
            b.append(e.getKey()).append(": ");
            Object v = e.getValue();
            if (v instanceof Collection) {
                b.append("\n");
                for (Object x : (Collection<?>)v) b.append("• ").append(x).append("\n");
            } else {
                b.append(v).append("\n");
            }
        }
        return b.toString().trim();
    }

    public static String prettyRows(List<Map<String,String>> rows) {
        if (rows.isEmpty()) return "No matching rows.";
        StringBuilder b = new StringBuilder();
        int n = 1;
        for (Map<String,String> r : rows) {
            b.append("#").append(n++).append("\n");
            for (Map.Entry<String,String> e : r.entrySet()) {
                if (!safe(e.getValue()).isEmpty())
                    b.append(e.getKey()).append(": ").append(e.getValue()).append("\n");
            }
            b.append("\n");
        }
        return b.toString().trim();
    }

    private static String bullets(String text) {
        if (safe(text).isEmpty()) return "- Not supplied.";
        String[] parts = text.split("\\r?\\n");
        StringBuilder b = new StringBuilder();
        for (String p : parts) if (!p.trim().isEmpty()) b.append("- ").append(p.trim()).append("\n");
        return b.toString().trim();
    }

    private static Map<String,Map<String,String>> indexRows(List<Map<String,String>> rows) {
        LinkedHashMap<String,Map<String,String>> out = new LinkedHashMap<>();
        for (Map<String,String> r : rows) {
            String k = safe(r.get("Product")) + "|" + safe(r.get("SKU")) + "|"
                    + safe(r.get("Market")) + "|" + safe(r.get("Segment")) + "|"
                    + safe(r.get("Term")) + "|" + safe(r.get("Billing")) + "|"
                    + safe(r.get("Currency"));
            out.put(k, r);
        }
        return out;
    }

    private static String label(Map<String,String> r) {
        return safe(r.get("Product")) + " / " + safe(r.get("SKU")) + " / " + safe(r.get("Market"));
    }

    public static List<Map<String,String>> parseCsv(String csv) {
        List<Map<String,String>> out = new ArrayList<>();
        List<List<String>> lines = parseCsvRows(csv);
        if (lines.isEmpty()) return out;
        List<String> header = lines.get(0);
        for (int i=1; i<lines.size(); i++) {
            List<String> row = lines.get(i);
            LinkedHashMap<String,String> m = new LinkedHashMap<>();
            for (int j=0; j<header.size(); j++) {
                m.put(header.get(j), j < row.size() ? row.get(j) : "");
            }
            out.add(m);
        }
        return out;
    }

    private static List<List<String>> parseCsvRows(String text) {
        List<List<String>> rows = new ArrayList<>();
        List<String> row = new ArrayList<>();
        StringBuilder cell = new StringBuilder();
        boolean quoted = false;

        for (int i=0; i<text.length(); i++) {
            char c = text.charAt(i);
            if (c == '"') {
                if (quoted && i+1 < text.length() && text.charAt(i+1) == '"') {
                    cell.append('"');
                    i++;
                } else quoted = !quoted;
            } else if (c == ',' && !quoted) {
                row.add(cell.toString());
                cell.setLength(0);
            } else if ((c == '\n' || c == '\r') && !quoted) {
                if (c == '\r' && i+1 < text.length() && text.charAt(i+1) == '\n') i++;
                row.add(cell.toString());
                cell.setLength(0);
                if (!allEmpty(row)) rows.add(row);
                row = new ArrayList<>();
            } else {
                cell.append(c);
            }
        }
        row.add(cell.toString());
        if (!allEmpty(row)) rows.add(row);
        return rows;
    }

    private static boolean allEmpty(List<String> row) {
        for (String x : row) if (!safe(x).isEmpty()) return false;
        return true;
    }

    private static String pick(Map<String,String> row, String... names) {
        for (String name : names) {
            String target = key(name);
            for (Map.Entry<String,String> e : row.entrySet()) {
                if (key(e.getKey()).equals(target)) return safe(e.getValue());
            }
        }
        return "";
    }

    private static String key(String s) {
        return safe(s).toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9]", "");
    }

    private static String norm(String s, String fallback) {
        String x = safe(s).toLowerCase(Locale.ROOT);
        return x.isEmpty() ? fallback : x;
    }

    private static String title(String s) {
        if (s == null || s.isEmpty()) return "";
        return Character.toUpperCase(s.charAt(0)) + s.substring(1);
    }

    private static String safe(Object s) {
        return s == null ? "" : String.valueOf(s).trim();
    }

    private static String join(List<String> items) {
        StringBuilder b = new StringBuilder();
        for (int i=0; i<items.size(); i++) {
            if (i>0) b.append(", ");
            b.append(items.get(i));
        }
        return b.toString();
    }
}
