package mu.mc3.presales;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.net.Uri;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.View;
import android.widget.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

public class ModuleActivity extends Activity {

    private LinearLayout form;
    private String module;
    private TextView output;
    private String csvA = "";
    private String csvB = "";
    private static final int PICK_A = 801;
    private static final int PICK_B = 802;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        setContentView(R.layout.activity_module);

        module = getIntent().getStringExtra("module");
        if (module == null) module = "windows";

        findViewById(R.id.backButton).setOnClickListener(v -> finish());
        form = findViewById(R.id.formContainer);
        setup();
    }

    private void setup() {
        switch (module) {
            case "windows": setupWindows(); break;
            case "sql": setupSql(); break;
            case "m365": setupM365(); break;
            case "copilot": setupCopilot(); break;
            case "keepit": setupKeepit(); break;
            case "bittitan": setupBitTitan(); break;
            case "cspsearch": setupCspSearch(); break;
            case "cspcompare": setupCspCompare(); break;
            case "partner": setupPartner(); break;
            case "brief": setupBrief(); break;
            default: setupWindows();
        }
    }

    private void title(String t, String sub) {
        ((TextView)findViewById(R.id.moduleTitle)).setText(t);
        ((TextView)findViewById(R.id.moduleSubtitle)).setText(sub);
    }

    private EditText input(String label, String hint, boolean numeric) {
        TextView l = new TextView(this);
        l.setText(label);
        l.setTextColor(Color.parseColor("#333333"));
        l.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        l.setPadding(0, dp(8), 0, dp(4));
        form.addView(l);

        EditText e = new EditText(this);
        e.setHint(hint);
        e.setSingleLine(false);
        e.setTextColor(Color.parseColor("#222222"));
        e.setHintTextColor(Color.parseColor("#999999"));
        e.setBackgroundColor(Color.WHITE);
        e.setPadding(dp(12), dp(10), dp(12), dp(10));
        if (numeric) e.setInputType(android.text.InputType.TYPE_CLASS_NUMBER | android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL);

        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, 0, 0, dp(8));
        e.setLayoutParams(lp);
        form.addView(e);
        return e;
    }

    private Spinner spinner(String label, String... values) {
        TextView l = new TextView(this);
        l.setText(label);
        l.setTextColor(Color.parseColor("#333333"));
        l.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        l.setPadding(0, dp(8), 0, dp(4));
        form.addView(l);

        Spinner s = new Spinner(this);
        ArrayAdapter<String> a = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, values);
        s.setAdapter(a);
        form.addView(s);
        return s;
    }

    private CheckBox check(String label) {
        CheckBox c = new CheckBox(this);
        c.setText(label);
        c.setTextColor(Color.parseColor("#333333"));
        c.setPadding(0, dp(6), 0, dp(6));
        form.addView(c);
        return c;
    }

    private Button action(String text, View.OnClickListener listener) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextColor(Color.WHITE);
        b.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.parseColor("#F37021")));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, dp(14), 0, dp(10));
        b.setLayoutParams(lp);
        b.setOnClickListener(listener);
        form.addView(b);
        return b;
    }

    private void addOutput() {
        TextView heading = new TextView(this);
        heading.setText("RESULT");
        heading.setTextColor(Color.parseColor("#F37021"));
        heading.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        heading.setTextSize(13);
        heading.setPadding(0, dp(14), 0, dp(6));
        form.addView(heading);

        output = new TextView(this);
        output.setText("No result yet.");
        output.setTextIsSelectable(true);
        output.setTextColor(Color.parseColor("#242424"));
        output.setTextSize(14);
        output.setPadding(dp(14), dp(14), dp(14), dp(14));
        output.setBackgroundResource(R.drawable.card_bg);
        form.addView(output);
    }

    private void result(Object obj) {
        try {
            if (obj instanceof Map) output.setText(PresalesEngine.pretty((Map<String,?>)obj));
            else output.setText(String.valueOf(obj));
        } catch (Exception ex) {
            output.setText("Error: " + ex.getMessage());
        }
    }

    private void setupWindows() {
        title("Windows Server", "Core licensing • Standard / Datacenter");
        Spinner edition = spinner("Edition", "Standard", "Datacenter");
        EditText servers = input("Servers", "1", true); servers.setText("1");
        EditText cpus = input("Processors / server", "2", true); cpus.setText("2");
        EditText cores = input("Cores / processor", "12", true); cores.setText("12");
        EditText vms = input("Windows Server VMs / server", "5", true); vms.setText("5");
        action("CALCULATE", v -> {
            try {
                result(PresalesEngine.windowsServer(
                        edition.getSelectedItem().toString(),
                        i(servers,1), i(cpus,1), i(cores,1), i(vms,0)));
            } catch (Exception e) { output.setText("Error: " + e.getMessage()); }
        });
        addOutput();
    }

    private void setupSql() {
        title("SQL Server", "Per Core • Server + CAL");
        Spinner edition = spinner("Edition", "Standard", "Enterprise");
        Spinner deployment = spinner("Deployment", "VM", "Physical");
        Spinner model = spinner("Licensing model", "Per Core", "Server + CAL");
        EditText cores = input("vCores / physical cores", "8", true); cores.setText("8");
        EditText cals = input("User CALs (if Server + CAL)", "0", true); cals.setText("0");
        action("ANALYZE", v -> {
            try {
                String m = model.getSelectedItem().toString().startsWith("Server") ? "server_cal" : "per_core";
                result(PresalesEngine.sqlServer(
                        edition.getSelectedItem().toString(),
                        deployment.getSelectedItem().toString(),
                        m, i(cores,4), i(cals,0)));
            } catch (Exception e) { output.setText("Error: " + e.getMessage()); }
        });
        addOutput();
    }

    private void setupM365() {
        title("Microsoft 365 BOM", "Overlap & duplicate review");
        EditText bom = input("Products", "One per line, optionally: Product | Quantity", false);
        bom.setMinLines(6);
        action("REVIEW BOM", v -> {
            List<String> products = new ArrayList<>();
            List<Integer> qty = new ArrayList<>();
            for (String line : bom.getText().toString().split("\\r?\\n")) {
                if (line.trim().isEmpty()) continue;
                String[] p = line.split("\\|");
                products.add(p[0].trim());
                qty.add(p.length > 1 ? parseInt(p[1].trim(), 1) : 1);
            }
            result(PresalesEngine.m365Bom(products, qty));
        });
        addOutput();
    }

    private void setupCopilot() {
        title("Copilot Studio", "Credits • PAYG • Capacity");
        EditText makers = input("Makers", "2", true); makers.setText("2");
        EditText users = input("End users", "800", true); users.setText("800");
        EditText credits = input("Expected monthly Copilot Credits (optional)", "60000", true);
        CheckBox predictable = check("Prefer predictable prepaid capacity");
        action("SIZE", v -> {
            String c = credits.getText().toString().trim();
            Integer val = c.isEmpty() ? null : parseInt(c, 0);
            result(PresalesEngine.copilotStudio(i(makers,0), i(users,0), val, predictable.isChecked()));
        });
        addOutput();
    }

    private void setupKeepit() {
        title("Keepit", "Backup & resilience discovery");
        EditText users = input("Protected users", "70", true); users.setText("70");
        EditText workloads = input("Workloads", "Exchange Online, OneDrive, SharePoint, Teams", false);
        workloads.setText("Exchange Online, OneDrive, SharePoint, Teams");
        EditText shared = input("Shared mailboxes", "0", true); shared.setText("0");
        action("BUILD PRESALES VIEW", v -> result(PresalesEngine.keepit(
                i(users,0), workloads.getText().toString(), i(shared,0))));
        addOutput();
    }

    private void setupBitTitan() {
        title("BitTitan", "MigrationWiz sizing");
        EditText users = input("Users", "120", true); users.setText("120");
        EditText workloads = input("Workloads", "Mailbox, OneDrive", false); workloads.setText("Mailbox, OneDrive");
        EditText size = input("Representative mailbox size (GB)", "40", true); size.setText("40");
        CheckBox docs = check("Documents / OneDrive migration");
        CheckBox archives = check("Personal archives");
        CheckBox outlook = check("Outlook profile reconfiguration");
        action("SIZE MIGRATION", v -> result(PresalesEngine.bittitan(
                i(users,1), workloads.getText().toString(), d(size,0),
                docs.isChecked(), archives.isChecked(), outlook.isChecked())));
        addOutput();
    }

    private void setupCspSearch() {
        title("CSP Price Search", "Search Partner Center CSV");
        Button pick = action("SELECT CSV FILE", v -> pickFile(PICK_A));
        EditText query = input("Product / SKU query", "Business Premium", false);
        EditText market = input("Market", "FR", false);
        EditText segment = input("Segment", "Commercial", false);
        action("SEARCH", v -> {
            if (csvA.isEmpty()) { output.setText("Select a CSV file first."); return; }
            List<Map<String,String>> rows = PresalesEngine.searchCspCsv(
                    csvA, query.getText().toString(), market.getText().toString(), segment.getText().toString());
            output.setText(PresalesEngine.prettyRows(rows));
        });
        addOutput();
    }

    private void setupCspCompare() {
        title("CSP Compare", "Compare two price lists");
        action("SELECT OLD CSV", v -> pickFile(PICK_A));
        action("SELECT NEW CSV", v -> pickFile(PICK_B));
        EditText query = input("Optional product filter", "Business Premium", false);
        action("COMPARE", v -> {
            if (csvA.isEmpty() || csvB.isEmpty()) { output.setText("Select both CSV files first."); return; }
            result(PresalesEngine.compareCspCsv(csvA, csvB, query.getText().toString()));
        });
        addOutput();
    }

    private void setupPartner() {
        title("Partner Center", "Build price-sheet request");
        EditText market = input("Market", "FR", false); market.setText("FR");
        Spinner view = spinner("Price sheet view", "software", "licensebasedest", "licensebasedeos", "marketplace", "azure_consumption", "azure_reservations");
        Spinner timeline = spinner("Timeline", "current", "history", "future");
        EditText month = input("History month (YYYYMM)", "202608", false);
        action("BUILD REQUEST", v -> {
            try {
                result(PresalesEngine.partnerCenterRequest(
                        market.getText().toString(),
                        view.getSelectedItem().toString(),
                        timeline.getSelectedItem().toString(),
                        month.getText().toString()));
            } catch (Exception e) { output.setText("Error: " + e.getMessage()); }
        });
        addOutput();
    }

    private void setupBrief() {
        title("Technical Brief", "Generate presales documentation");
        EditText scenario = input("Customer scenario", "Describe the customer situation", false);
        EditText environment = input("Current environment", "One item per line", false);
        EditText requirements = input("Requirements", "One item per line", false);
        EditText components = input("Proposed components", "One item per line", false);
        EditText risks = input("Risks / assumptions", "One item per line", false);
        action("GENERATE BRIEF", v -> output.setText(PresalesEngine.technicalBrief(
                scenario.getText().toString(),
                environment.getText().toString(),
                requirements.getText().toString(),
                components.getText().toString(),
                risks.getText().toString())));
        addOutput();
    }

    private void pickFile(int code) {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("text/*");
        startActivityForResult(i, code);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null || data.getData() == null) return;
        try {
            String content = readUri(data.getData());
            if (requestCode == PICK_A) csvA = content;
            if (requestCode == PICK_B) csvB = content;
            Toast.makeText(this, "CSV loaded", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "Read error: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private String readUri(Uri uri) throws Exception {
        InputStream in = getContentResolver().openInputStream(uri);
        if (in == null) throw new IOException("Cannot open file");
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        byte[] buf = new byte[8192];
        int n;
        while ((n = in.read(buf)) > 0) out.write(buf,0,n);
        in.close();
        return new String(out.toByteArray(), StandardCharsets.UTF_8);
    }

    private int i(EditText e, int fallback) { return parseInt(e.getText().toString(), fallback); }
    private double d(EditText e, double fallback) {
        try { return Double.parseDouble(e.getText().toString().trim()); } catch(Exception x) { return fallback; }
    }
    private int parseInt(String x, int fallback) {
        try { return Integer.parseInt(x.trim()); } catch(Exception e) { return fallback; }
    }
    private int dp(int n) { return Math.round(n * getResources().getDisplayMetrics().density); }
}
