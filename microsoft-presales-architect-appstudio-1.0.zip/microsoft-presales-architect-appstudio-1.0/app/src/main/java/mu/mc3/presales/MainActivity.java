package mu.mc3.presales;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.View;
import android.widget.*;

public class MainActivity extends Activity {

    private static final String[][] MODULES = {
            {"windows", "Windows Server", "Core licensing • Standard / Datacenter"},
            {"sql", "SQL Server", "Per Core • Server + CAL"},
            {"m365", "Microsoft 365 BOM", "Overlap & duplicate review"},
            {"copilot", "Copilot Studio", "Credits • PAYG • Capacity"},
            {"keepit", "Keepit", "Backup & resilience discovery"},
            {"bittitan", "BitTitan", "MigrationWiz sizing"},
            {"cspsearch", "CSP Price Search", "Search Partner Center CSV"},
            {"cspcompare", "CSP Compare", "Compare two price lists"},
            {"partner", "Partner Center", "Build price-sheet request"},
            {"brief", "Technical Brief", "Generate presales documentation"}
    };

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        setContentView(R.layout.activity_main);

        LinearLayout list = findViewById(R.id.moduleList);
        for (String[] m : MODULES) {
            list.addView(makeCard(m[0], m[1], m[2]));
        }
    }

    private View makeCard(String id, String title, String subtitle) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(18), dp(16), dp(18), dp(16));
        card.setBackgroundResource(R.drawable.card_bg);
        card.setClickable(true);
        card.setFocusable(true);

        TextView t = new TextView(this);
        t.setText(title);
        t.setTextSize(19);
        t.setTextColor(Color.parseColor("#242424"));
        t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        card.addView(t);

        TextView s = new TextView(this);
        s.setText(subtitle);
        s.setTextSize(13);
        s.setTextColor(Color.parseColor("#6F6F6F"));
        s.setPadding(0, dp(4), 0, 0);
        card.addView(s);

        TextView arrow = new TextView(this);
        arrow.setText("OPEN  ›");
        arrow.setTextColor(Color.parseColor("#F37021"));
        arrow.setTextSize(12);
        arrow.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        arrow.setPadding(0, dp(10), 0, 0);
        card.addView(arrow);

        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, 0, 0, dp(12));
        card.setLayoutParams(lp);

        card.setOnClickListener(v -> {
            Intent i = new Intent(MainActivity.this, ModuleActivity.class);
            i.putExtra("module", id);
            startActivity(i);
        });
        return card;
    }

    private int dp(int n) {
        return Math.round(n * getResources().getDisplayMetrics().density);
    }
}
