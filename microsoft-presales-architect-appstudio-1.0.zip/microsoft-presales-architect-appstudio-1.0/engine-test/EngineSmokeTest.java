import mu.mc3.presales.PresalesEngine;
import java.util.*;

public class EngineSmokeTest {
    public static void main(String[] args) {
        Map<String,Object> w = PresalesEngine.windowsServer("Standard",1,2,12,5);
        if (!w.get("Total core licenses").equals(72)) throw new RuntimeException("Windows test failed");

        Map<String,Object> s = PresalesEngine.sqlServer("Standard","VM","per_core",8,0);
        if (!s.get("Licensed cores").equals(8)) throw new RuntimeException("SQL test failed");

        Map<String,Object> c = PresalesEngine.copilotStudio(2,800,60000,true);
        if (!c.get("Estimated capacity packs").equals(3)) throw new RuntimeException("Copilot test failed");

        Map<String,Object> b = PresalesEngine.bittitan(2,"Mailbox",110,false,false,false);
        if (!b.get("Estimated mailbox licenses").equals(6)) throw new RuntimeException("BitTitan test failed");

        System.out.println("PASS - PresalesEngine core smoke tests");
    }
}
